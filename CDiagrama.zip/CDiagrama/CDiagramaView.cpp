﻿
// CDiagramaView.cpp : implementation of the CCDiagramaView class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "CDiagrama.h"
#endif

#include "CDiagramaDoc.h"
#include "CDiagramaView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCDiagramaView

IMPLEMENT_DYNCREATE(CCDiagramaView, CView)

BEGIN_MESSAGE_MAP(CCDiagramaView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CCDiagramaView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
END_MESSAGE_MAP()

// CCDiagramaView construction/destruction

CCDiagramaView::CCDiagramaView() noexcept
{
	// TODO: add construction code here

}

CCDiagramaView::~CCDiagramaView()
{
}

BOOL CCDiagramaView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CCDiagramaView drawing
// CDiagramaView drawing 
#include "stdlib.h" 
#include "string.h" 
#include "math.h" 
//#define nf 5//7 
//#define mf 5//11 

void CCDiagramaView::OnDraw(CDC* pDC)
{
	CCDiagramaDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
	const int nf = 5;
	//static 
	float diagr[nf] =
	{ 30.0, 20.5, 57.0, 10.5, 15.0 };//,40., 5., 36., 46., 18., 28.}; 
	//static 
	char denum[nf][20] =
	{ "Alfa","Beta","Gama","Delta","Epsilon" };//,"Omega","Psi","Sigma","Teta","Lambda","Kapa"}; 
		int ky = 4;
	int k;
	char numc[4];
	CPen pAxe(PS_SOLID, 1, RGB(0, 0, 255));
	CBrush brYellow(RGB(255, 255, 0));
	CBrush brUmplere(RGB(255, 0, 255));
	// CBrush brU(RGB(255,255,0)); 

	pDC->SelectObject(&brUmplere);
	CFont fAreal;
	fAreal.CreatePointFont(100, _T("Areal"), pDC); // Utilizați o valoare mai mare pentru dimensiunea fontului


	CPen* pOldPen = pDC->SelectObject(&pAxe);
	CBrush* pOldBrush = pDC->SelectObject(&brUmplere);
	// CBrush* pOldBrush=(CBrush*)pDC->SelectStockObject(NULL_BRUSH); // ??? 
	CFont* pOldFont = pDC->SelectObject(&fAreal);
	CRect rcClient;
	GetClientRect(&rcClient);
	int maxx = rcClient.Width(),
		maxy = rcClient.Height();
	pDC->SetViewportOrg(0, 0);
	pDC->SetViewportExt(maxx, maxy);
	//* Granita 
	pDC->SelectStockObject(NULL_BRUSH);
	pDC->Rectangle(0, 0, maxx, maxy);
	//* Antet 
	pDC->SetTextColor(RGB(128, 0, 0));
	pDC->SetTextAlign(TA_CENTER + TA_TOP);//+TA_NOUPDATECP);
	pDC->TextOutW(maxx / 2, 5, _T("DIAGRAMA"), 8);

	//* Axe 
	//pDC->MoveTo(40,50); 
	 //pDC->LineTo(40,maxy-40); 
	//pDC->MoveTo(40,50); 
	//pDC->LineTo(37,56); 
	//pDC->MoveTo(40,50); 
	//pDC->LineTo(42,56); 
	pDC->MoveTo(40, maxy - 40);
	pDC->LineTo(40, 50);
	pDC->LineTo(37, 56);
	pDC->MoveTo(40, 50);
	pDC->LineTo(42, 56);
	//* Gradarea axei Y 
   // pDC->SetTextAlign(TA_LEFT+TA_BOTTOM+TA_NOUPDATECP); 
	pDC->SetTextAlign(TA_LEFT + TA_BASELINE);//+TA_NOUPDATECP); 
	// pDC->SetTextAlign(TA_LEFT+TA_TOP+TA_NOUPDATECP);
	// pDC->SetTextAlign(TA_CENTER+TA_NOUPDATECP); 
	for (k = 0; maxy - 40 - k * ky >= 50; k += 10)
	{

		// CString gnum; 
		// gnum.Format("%d", k); 
		// pDC->TextOut(10,maxy-40-k*ky+5,gnum); 
		_itoa_s(k, numc, 10);
		pDC->TextOut(10, maxy - 40 - k * ky + 5, CString(numc), strlen(numc));
		pDC->MoveTo(40 - 3, maxy - 40 - k * ky);
		pDC->LineTo(40 + 3, maxy - 40 - k * ky);
	}
	//* Diagrama dreptunghiulara 
	for (k = 0; k < nf; k++)
	{
		brUmplere.DeleteObject();
		brUmplere.CreateSolidBrush
		(RGB(k % 2 ? 255 - 40 * (k + 1) : 255, k % 3 ? 255 - 60 * (k + 1) : 255,
			k % 5 ? 200 : 40 * (k + 1)));
		pDC->SelectObject(brUmplere); 

		/*brUmplere.DeleteObject();
		brUmplere.CreateHatchBrush(HS_HORIZONTAL + k, RGB(255, 0, 255));
		pDC->SelectObject(brUmplere);
		*/
		pDC->Rectangle(50 + 40 * k + 5, maxy - 40,
			50 + 40 * (k + 1), maxy - 40 - (int)(ky * diagr[k]));
		//floodfill(50+40*k+1,maxy-40-1,WHITE); 
		//bar3d(50+40*k+15, maxy-40, 
		//50+40*(k+1), maxy-40-ky*diagr[k],15,1); 
	}
	//* Diagrama Pie 
	pDC->SelectStockObject(NULL_PEN);
	double stangle, endangle, ugrad;
	double suma;
	double pi = 4.0 * atan(1.0);
	int radius = maxy / 5;
	CPoint ptCenter, ptStart, ptEnd;
	ptCenter = CPoint(4 * maxx / 5, maxy / 4);
	CRect rcPie(ptCenter, ptCenter);
	rcPie.InflateRect(radius, radius);
	suma = 0.0;
	for (k = 0; k < nf; k++)
		suma += diagr[k];
	stangle = 0.0;
	ptStart = CPoint(ptCenter.x + radius, ptCenter.y);
	for (k = 0; k < nf; k++)
	{
		brUmplere.DeleteObject();
		brUmplere.CreateSolidBrush
		(RGB(k % 2 ? 255 - 40 * (k + 1) : 255, k % 3 ? 255 - 60 * (k + 1) : 255,
			k % 5 ? 200 : 40 * (k + 1)));
		pDC->SelectObject(brUmplere);
		ugrad = pi / 180. * (stangle + 3);
		ptStart = CPoint(ptCenter.x + (int)(radius * cos(ugrad)),
			ptCenter.y - (int)(radius * sin(ugrad)));
		endangle = (k < nf - 1) ? stangle + diagr[k] * 360. / suma : 360.;
		ugrad = pi / 180. * (endangle - 3);
		ptEnd = CPoint(ptCenter.x + (int)(radius * cos(ugrad)),
			ptCenter.y - (int)(radius * sin(ugrad)));
		pDC->Pie(rcPie, ptStart, ptEnd);
		//ptStart=ptEnd; 
		stangle = endangle;
	}

	//* Legenda 
	pDC->SetTextColor(RGB(128, 255, 0));
	for (k = 0; k < nf; k++)
	{
		brUmplere.DeleteObject();
		brUmplere.CreateSolidBrush
		(RGB(k % 2 ? 255 - 40 * (k + 1) : 255, k % 3 ? 255 - 60 * (k + 1) : 255,
			k % 5 ? 200 : 40 * (k + 1)));
		pDC->SelectObject(brUmplere);

		pDC->Rectangle(7 * maxx / 8 - 60, maxy / 2 - 8 + 20 * (k + 1) - 10,
			7 * maxx / 8 - 20, maxy / 2 - 8 + 20 * (k + 1) + 8);
		pDC->TextOut(7 * maxx / 8, maxy / 2 + 20 * (k + 1) - 2,
			CString(denum[k]), strlen(denum[k]));
	}
	pDC->SelectObject(pOldPen);
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldFont);
}


// CCDiagramaView printing


void CCDiagramaView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CCDiagramaView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CCDiagramaView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CCDiagramaView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CCDiagramaView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CCDiagramaView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CCDiagramaView diagnostics

#ifdef _DEBUG
void CCDiagramaView::AssertValid() const
{
	CView::AssertValid();
}

void CCDiagramaView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCDiagramaDoc* CCDiagramaView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCDiagramaDoc)));
	return (CCDiagramaDoc*)m_pDocument;
}
#endif //_DEBUG


// CCDiagramaView message handlers
